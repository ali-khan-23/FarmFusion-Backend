// backend/routes/dashboard.js
const express = require('express');
const router = express.Router();
const Cattle = require('../models/Cattle');
const Vaccination = require('../models/Vaccination');
const Breeding = require('../models/Breeding');
// Add other models as needed

router.get('/stats', async (req, res) => {
  try {
    const totalCattle = await Cattle.countDocuments();
    const vaccinated = await Vaccination.countDocuments();
    const breeding = await Breeding.countDocuments();
    const available = await Cattle.countDocuments({ available: true });
    const sold = await Cattle.countDocuments({ sold: true });

    res.json({
      totalCattle,
      vaccinated,
      breeding,
      available,
      sold,
      medicines: 27, // Optional: replace with real count
      diet: 'Live',
      buyNow: 80 // Optional: replace with real data
    });
  } catch (err) {
    res.status(500).json({ error: 'Server Error' });
  }
});

module.exports = router;
