const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const Availability = require("../models/Availability");

// ✅ Admin-only route (only users with role "admin" can access)
router.get("/admin-dashboard", auth(["admin"]), (req, res) => {
  res.json({ message: "Welcome Admin" });
});

// ✅ GET all availability (any logged-in user can see)
router.get("/", auth(), async (req, res) => {
  try {
    const data = await Availability.find();
    res.json(data);
  } catch (err) {
    console.error("Error fetching availability:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ POST new availability (admin only)
router.post("/", auth(["admin"]), async (req, res) => {
  try {
    const newEntry = new Availability(req.body);
    await newEntry.save();
    res.status(201).json(newEntry);
  } catch (err) {
    console.error("Error creating availability:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ DELETE availability (admin only)
router.delete("/:id", auth(["admin"]), async (req, res) => {
  try {
    await Availability.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
  } catch (err) {
    console.error("Error deleting availability:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ UPDATE availability (admin only)
router.put("/:id", auth(["admin"]), async (req, res) => {
  try {
    const updated = await Availability.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    console.error("Error updating availability:", err);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
