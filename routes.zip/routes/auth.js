// routes/auth.js
const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const User = require("../models/User");

// ✅ REGISTER route
router.post("/register", async (req, res) => {
  const { name, email, phone, address, password, role } = req.body;

  try {
    // Check if user already exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: "User already exists" });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create new user with extra fields
    user = new User({
      name,
      email,
      phone,
      address,
      password: hashedPassword,
      role: role || "user", // default role
    });

    await user.save();

    res.status(201).json({ msg: "User registered successfully" });
  } catch (err) {
    console.error("Error in register route:", err.message);
    res.status(500).send("Server error");
  }
});

// ✅ don’t forget this!
module.exports = router;
